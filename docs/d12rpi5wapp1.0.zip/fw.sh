#!/bin/bash

# this is all based on a bunch of volunteer stations around the country:
#   https://www.weatherusa.net/radio
# and most of the time Wilmington is offline , so try VB feed.

cd /home/admin/Documents

# RDD process gets out of control from firefox sandboxing
myPID=`ps -o pid,user,comm -u admin | grep -i rdd | xargs -n1 | head -1`
kill -9 $myPID

#if there are any running audio, stop them , so the noaa weather stream can play
myPID=`ps -o pid,user,comm -u admin | grep -i vlc | xargs -n1 | head -1`
kill -9 $myPID

echo "fetching noaa weather audio"

# play this many seconds of noaa weather audio
PLAY_TIME=180


# use VB stream
RADIO_URL="https://radio.weatherusa.net/NWR/KHB37_3.mp3"

echo "Starting download and running for ${FETCH_TIME}"

cvlc --gain=4 ${RADIO_URL} & 
sleep $PLAY_TIME
kill $!

# start up an ad-free easy listening classic rock stream from denmark i think
cvlc --gain=1 http://mediaserv68.live-streams.nl:8070/stream

#another radio stream : http://relay.181.fm:8000/

