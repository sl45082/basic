
#  install the hide cursor lib and conf so wayland can pick it up
# update the ~/.config/wayfire.ini to include a new section: 
# [core]
# plugins = autostart autostart-static command pixdecor expo grid move place resize switcher vswitch window-rules wm-actions wort zoom hide-cursor


echo "installing hide cursor plugin"

# copy in files
sudo cp libhide-cursor.so /usr/lib/aarch64-linux-gnu/wayfire/
sudo chmod 644 /usr/lib/aarch64-linux-gnu/wayfire/libhide-cursor.so 
sudo cp hide-cursor.xml /usr/share/wayfire/metadata/
sudo chmod 644 /usr/share/wayfire/metadata/hide-cursor.xml

