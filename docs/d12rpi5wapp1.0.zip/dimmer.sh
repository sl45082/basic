#!/bin/bash

# "turning monitor off"
#wlr-randr --output HDMI-A-1 --off
# "turning monitor on"
#wlr-randr --output HDMI-A-1 --on

DAYLIGHT="EST"
START="5"
END="21"
TZ=`date +%Z`
if [ "${TZ}" == "${DAYLIGHT}" ]; 
then 
	START="6"
	END="20"
fi

APP_DOWN=false
while : 
do
	HOUR=`date +%H`
	echo "The hour is ${HOUR}."
	# only show the app from START and END for retail installs
	if [ "${HOUR}" -le "${START}" -o "${HOUR}" -gt "${END}" ]; 
	then 
		echo "dimmer: enable monitor dimming" 
		wlr-randr --output HDMI-A-1 --off
		# shutdown the app
		pkill -f firefox
		APP_DOWN=true
	else
		echo "dimmer: leaving monitor on" 
		wlr-randr --output HDMI-A-1 --on
		if [[ ${APP_DOWN} == true ]];
		then
			#lets reboot, been asleep alot
			reboot
		fi
	fi
	sleep 1920
done
