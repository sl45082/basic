// to be used to set firefox config options
user_pref("browser.sessionstore.resume_from_crash", false);
