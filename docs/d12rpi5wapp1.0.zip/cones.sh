
# this file helps handle cases where its not hurricane season or no storms actively tracking
# need to have good weather info in cones.html and the 7day.html

# sleep for a bit so network/wifi is up and dont overload system with i/o
sleep 45

# need to see what happening in the atlantic, so 
# get the nhc noaa homepage and look for any hurricanes and related images
wget -O /tmp/nhc-noaa "https://www.nhc.noaa.gov/" -o log.hp

# ============= 7day section ============ #
NO_STORMS=`grep "are no tropical cyclones in the Atlantic" /tmp/nhc-noaa | wc -l | tr -d " "`

if (( $NO_STORMS )); then
	# there are no tropical storms, show the rain/weather/wind forecast
	echo "there are no hurricanes found"
	cp nc-rain.html 7day.html
else
	#there is a storm somewhere ,show the 7 day atlantic outlook
	echo "there is a (probably) hurricane in atlantic"
	h1="https://www.nhc.noaa.gov/xgtwo/two_atl_7d0.png"
	echo " <html> <body> <center> <img src=${h1}> </center> </body> </html>" > 7day.html
fi


# ============= Cones section ============ #
#hurricane season is half the year, so we need an image if there are no active storms with cones
NO_CONE="https://s.w-x.co/staticmaps/severe_us_1280x720.jpg?crop=16:9&width=1200&format=pjpg&auto=webp&quality=100"

# TODO below logic is a hack, needs to be refined to handle: multiple simultaneous storms and filter on atlantic only
# this does not prove its in the atlantic, only that there is a storm present somewhere with a 5day cone
i1=`cat /tmp/nhc-noaa | tr ' ' '\n' | grep 5day_cone | grep src | cut -d '=' -f2 | sed 's/_sm//g' |tr -d \''"\' | cut -d' ' -f1`
i1_len=`echo $i1 | wc -c`

#see if there is some valid image link in the page and use it, otherwise fall back into no hurricane mode
if [[ $i1_len -gt 90 ]]; 
then
	# there is a cone path, lets get the image and display
	echo "png path is: ${i1}"
	c1="https://www.nhc.noaa.gov${i1}"
	echo "cone path is: ${c1}"
else
	c1="${NO_CONE}"
fi

echo " <html> <body> <center> <img src=${c1}> </center> </body> </html>" > cones.html


