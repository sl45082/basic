
# sleep for a bit so network/wifi is up
sleep 45

#hurricane season is half the year, so we need an image if there are no active storms with cones
NOHURRICANE="https://s.w-x.co/staticmaps/severe_us_1280x720.jpg?crop=16:9&width=1200&format=pjpg&auto=webp&quality=100"

# get the nhc noaa homepage and look for any hurricanes and related images
wget -O /tmp/nhc-noaa "https://www.nhc.noaa.gov/" -o log.hp

i1=`cat /tmp/nhc-noaa | tr ' ' '\n' | grep 5day_cone | grep src | cut -d '=' -f2 | sed 's/_sm//g' |tr -d \''"\' | cut -d' ' -f1`
i1_len=`echo $i1 | wc -c`

#see if there is some valid image link in the page and use it, otherwise fall back into no hurricane mode
if [[ $i1_len -gt 90 ]]; 
then
	echo "png path is: ${i1}"
	p1="https://www.nhc.noaa.gov${i1}"
	echo "cone path is: ${p1}"
else
	p1="${NOHURRICANE}"
fi

echo " <html> <body> <center> <img src=${p1}> </center> </body> </html>" > cones.html
